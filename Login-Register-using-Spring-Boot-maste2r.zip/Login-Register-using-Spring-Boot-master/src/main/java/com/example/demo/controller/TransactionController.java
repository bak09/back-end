package com.example.demo.controller;

import com.example.demo.model.Transaction;
import com.example.demo.model.User;
import com.example.demo.service.TransactionService;
import com.example.demo.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // ✅ Теперь это REST API
@RequestMapping("/transactions")
public class TransactionController {

    private final TransactionService transactionService;
    private final UserRepository userRepository;
    private Long id;
    private double amount;
    private String description;

    public TransactionController(TransactionService transactionService, UserRepository userRepository) {
        this.transactionService = transactionService;
        this.userRepository = userRepository;
    }

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        return userRepository.findByEmail(username)
                .orElseThrow(() -> new RuntimeException("Пользователь не найден"));
    }

    // Получить список транзакций
    @GetMapping("/homepage")
    public List<Transaction> getMyTransactions() {
        User user = getCurrentUser();
        return transactionService.getTransactionsByUser(user.getId());
    }

    // Создать новую транзакцию
    @PostMapping("/create")
    public Transaction createTransaction(@RequestParam("amount") double amount,
                                         @RequestParam("description") String description) {
        User user = getCurrentUser();
        Transaction transaction = new Transaction(amount, description);
        transaction.setUser(user);
        return transactionService.createTransaction(transaction);
    }

    // Удалить транзакцию
    @DeleteMapping("/delete/{id}")
    public String deleteTransaction(@PathVariable Long id) {
        System.out.println("ID: " + id);  // ✅ Проверяем, какой ID передаётся
        User user = getCurrentUser();
        Optional<Transaction> transactionOpt = transactionService.getTransactionById(id);

        if (transactionOpt.isEmpty()) {
            return "Транзакция не найдена";
        }

        Transaction transaction = transactionOpt.get();
        if (!transaction.getUser().getEmail().equals(user.getEmail())) {
            return "Вы не можете удалить чужую транзакцию";
        }

        transactionService.deleteTransaction(id);
        return "Транзакция удалена";
    }

    // Обновить транзакцию
    @PutMapping("/update/{id}")
    public Transaction updateTransaction(@PathVariable Long id,
                                         @RequestParam double amount,
                                         @RequestParam String description) {

        User user = getCurrentUser();
        Transaction transaction = transactionService.getTransactionById(id)
                .orElseThrow(() -> new RuntimeException("Транзакция не найдена"));

        if (!transaction.getUser().getEmail().equals(user.getEmail())) {
            throw new RuntimeException("Вы не можете обновить чужую транзакцию");
        }

        transaction.setAmount(amount);
        transaction.setDescription(description);
        return transactionService.updateTransaction(transaction);
    }
}